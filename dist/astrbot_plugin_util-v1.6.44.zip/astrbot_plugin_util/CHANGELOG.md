# v1.6.44

- 新增插件级 `requirements.txt`，声明 `markitdown-no-magika[docx,xls,xlsx]` 与 `pypdf`，便于 AstrBot 安装插件时自动下载文档解析依赖。
- 更新文档解析说明，明确 Word、Excel、PowerPoint 等格式由 MarkItDown 依赖提供支持。

# v1.6.43

- 新增大模型文档解析工具 `parse_document(index, path, max_chars)`，可解析当前消息或引用消息中的文件并返回 Markdown 文本。
- 文档解析优先使用 MarkItDown，未安装时 PDF 使用 `pypdf` 兜底，文本、Markdown、CSV、HTML 等格式直接读取。
- 新增 `document_parse` 配置段，可控制工具开关、返回长度、文件大小上限以及是否允许显式本地路径。

# v1.6.42

- 新增大模型网易云音乐聚合工具 `netease_music(action, keyword, index)`，通过 `action=search` 搜索歌曲、`action=select` 按候选编号点歌。
- `/点歌` 指令与大模型工具复用同一套搜索缓存和选歌发送逻辑，保持人工指令行为不变。

# v1.6.41

- 修复 `/点歌`、`/music`、`/听歌`、`/网易云` 搜索包含空格的歌名时只取到第一个词的问题。
- 点歌搜索现在会优先从原始消息中剥离完整命令参数，例如 `/点歌 Shape of You` 会完整搜索 `Shape of You`。

# v1.6.40

- 修复表情回应 `set_msg_emoji_like` 在非群聊消息上触发导致整轮处理报错的问题。
- 表情回应现在只处理 AIOCQHTTP 群聊消息；平台拒绝设置表情时只记录 warning，不再向用户发送插件异常提示。

# v1.6.39

- `qq_mail_tool` 新增 `display_name` 配置项，可设置 QQ 邮箱 AI 工具发送邮件时的发件人显示名。
- SMTP 发信支持 `From: 显示名 <邮箱地址>`，留空时保持显示邮箱地址。

# v1.6.38

- 移除 `qqmail` 的 `status` action，减少大模型工具选择分支。
- QQ 邮箱工具改为在执行 `list/read/search/send/trash` 时自然连接 SMTP/IMAP 并验证授权是否可用。

# v1.6.37

- 废弃 QQ Agent `agently-cli` 邮箱方案，改为直接使用 QQ 邮箱授权码：SMTP 负责发信，IMAP 负责状态、列信、读信、搜索和移动到废纸篓。
- 新增独立 `qq_mail_tool` 配置项，与 `offline_email_alert` 下线通知配置完全分离，可使用不同邮箱和授权码。
- 移除 `/QQ邮箱登录`、`/QQ邮箱状态` 人工指令和 `core/agently_mail.py` CLI 封装。
- `qqmail` 聚合工具支持 `status/list/read/search/send/trash`。

# v1.6.36

- 移除 QQ Agent 邮箱写操作二次确认流程：`qqmail` 在 `allow_write_operations` 开启后会直接执行发送、回复、转发和移动到废纸篓。
- 删除 `/QQ邮箱确认` 管理指令和待确认操作持久化逻辑。
- 收窄面向大模型的 `qqmail` 工具提示词，只保留邮箱动作和参数用途，不暴露管理员确认、token 或内部流程说明。

# v1.6.35

- 优化聚合 QQ 邮箱 LLM 工具 `qqmail` 的提示词，补充 action 含义、参数用途、必填场景和二次确认说明，降低模型首次使用时的理解成本。

# v1.6.34

- 聚合 QQ Agent 邮箱 LLM 工具：将 7 个独立 `qqmail_*` 工具合并为单个 `qqmail(action, ...)`，降低工具数量和模型选择成本。
- 保留原有读写能力与管理员二次确认流程；读操作通过 `action=list/read/search`，写操作通过 `action=send/reply/forward/trash`。

# v1.6.33

- 新增 QQ Agent 邮箱 CLI 工具：封装 `@tencent-qqmail/agently-cli`，提供 `/QQ邮箱登录`、`/QQ邮箱状态`、`/QQ邮箱确认` 管理指令。
- 新增 QQ 邮箱 LLM 工具：列出、读取、搜索邮件可直接使用；发送、回复、转发、删除只生成 `confirmation_token`，必须由管理员二次确认。
- 新增 `agently_mail` 配置项，支持功能开关、CLI 路径、工作区、超时、默认列表数量、工具开关、写操作开关和管理员 QQ 列表。

# v1.6.32

- 修正 AI 主动语音发送工具的 TTS 接入方式：按 `li_qwen3_tts_api/cosyvoice_generate.py` 调用阿里云百炼 CosyVoice 远程 SpeechSynthesizer 接口，而不是本地 `/generate` 服务。
- `ai_voice` 默认接口地址改为 `https://dashscope.aliyuncs.com/api/v1/services/audio/tts/SpeechSynthesizer`，`audio_id` 作为 `input.voice`，`language` 作为 `input.language_hints`，`instruction` 作为 `input.instruction`。
- 新增 `model`、`audio_format`、`sample_rate` 配置项，默认分别为 `cosyvoice-v3.5-plus`、`wav`、`24000`。

# v1.6.31

- `send_voice_to_user` 新增 `instruction` 参数，可用自然语言影响语音生成的语速、情绪、语气、口音和朗读风格。
- `ai_voice` 新增默认 `instruction` 与 `max_instruction_chars` 配置项；请求 TTS 服务时会同时携带 `instruction` 和 `instructions` 字段以兼容不同服务端实现。

# v1.6.30

- 新增 `send_voice_to_user` 大模型工具，可调用外部 TTS API 生成语音并发送到当前会话。
- 新增 `ai_voice` 配置项，支持开关、API 地址、音频 ID、鉴权 token、默认语言、超时和文本长度上限。
- 语音生成结果会落地到 AstrBot 插件数据目录后以本地语音发送，日志不会输出 token 内容。

# v1.6.29

- 修复输出流重整使用合并转发打包发送时，分割消息超过 100 个节点会发送失败的问题；现在会按每批最多 100 个节点拆成多条合并转发发送。

# v1.6.28

- 移除 `/麦` 麦当劳 MCP 指令组及其配置、文档和测试；该 MCP 服务不稳定，避免继续暴露为插件功能。

# v1.6.26

- 修复角色资料库在运行环境缺少 `cs/output` 源资料时被启动重建流程清空的问题；现在源资料为空或不存在时会保留随包 SQLite 数据库。
- 增强角色资料库初始化日志，额外输出 SQLite 文件是否存在、文件大小、源目录是否存在、源 Markdown 数量、重建加载数量和是否跳过重建。

# v1.6.25

- 增强角色资料库搜索日志：插件启动时输出资料库路径、源资料目录和各库文档数量；每次搜索输出库名、query、拆分关键词、候选数量、去重数量、评分数量、返回数量和返回文档来源，便于定位数据库未加载或检索条件异常。

# v1.6.24

- 调整角色资料库搜索匹配逻辑：多个关键词现在按“任一关键词命中后再按分数排序”返回结果，避免模型把“魔女岛”“角色”等泛词加入 query 后导致具体角色资料搜不到。

# v1.6.23

- 修复角色资料库搜索工具配置读取问题：插件启动时传入 `roleplay_knowledge` 配置小节后，现在会正确读取 `enable_roleplay_knowledge_tool`，避免工具在人设工具集中存在但发送给模型前被误移除。

# v1.6.22

- 角色资料库的 12 份“对他人认知”文档现在会合并对应 roleplay skill 中的角色资料片段。
- 艾玛资料库合并 `ema-roleplay` 的角色条目与 cast-style 摘要；希罗资料库合并 `hiro-roleplay` 的角色 dossier 与 cast-style 摘要。

# v1.6.21

- 重构角色资料库入库规则：艾玛与希罗各保留 12 份“对他人认知”资料和 1 份公共背景词典，移除自身设定资料。
- `search_roleplay_knowledge` 工具说明补充 13 名主要角色关键词，方便模型在不知道具体资料文件名时检索。
- 新增 `roleplay_knowledge.deduplicate_turns`，最近 N 轮对话内不会重复返回同一份资料文档。

# v1.6.20

- 将角色资料库 SQLite 文件移动到插件目录 `roleplay_knowledge/roleplay_knowledge.sqlite3`，使数据库文件可被 git 管理。
- 角色资料库读取改为插件内相对路径，并在运行时以插件根目录解析，避免依赖 AstrBot 插件数据目录。

# v1.6.19

- 将角色资料库从运行时内存索引改为 SQLite 数据库。
- 角色资料库启动时会从 `cs/output` 重建到数据库，搜索工具从数据库读取资料，并继续按 `ni` / 其他配置区分艾玛与希罗资料库。

# v1.6.18

- 新增角色资料库搜索工具 `search_roleplay_knowledge`，可把 `cs/output` 中的角色扮演资料作为本地资料库供大模型检索。
- 新增 `roleplay_knowledge` 配置开关；当前配置文件名称为 `ni` 时使用艾玛资料库，其他配置默认使用希罗资料库。

# v1.6.17

- 新增下线 Webhook 发送端 `offline_webhook_senders`：检测到 AIOCQHTTP `bot_offline` notice 后可向多个 HTTP 接收端推送签名 JSON。
- 新增下线 Webhook 接收端 `offline_webhook_receiver` 与接收规则 `offline_webhook_receive_rules`：收到合法签名后可向指定机器人会话主动发送提醒，并支持消息模板和 @ 目标。

# v1.6.16

- 移除 `offline_mail_monitors` 邮箱下线检测端、IMAP 轮询逻辑、检测端配置项和对应测试。
- 保留 `offline_email_alert`：AIOCQHTTP 上报账号下线 notice 时仍会自动发送告警邮件。

# v1.6.15

- 邮箱下线检测端新增 `imap_timeout_seconds` 配置，默认 20 秒，避免 IMAP 网络异常时初始化长时间卡住。
- 邮箱下线检测端初始化失败或每轮检查结束后，会打印等待下次检查的原因、等待秒数和预计时间。

# v1.6.14

- 增强邮箱下线检测端日志：启动时打印脱敏配置摘要，初始化失败和轮询失败输出完整异常堆栈。
- 邮箱下线检测端每轮轮询都会打印 last_uid、新邮件数、拉取数、命中告警数、搜索 UID 和状态更新信息。

# v1.6.13

- 新增 `scripts/send_test_email.py` QQ SMTP 测试脚本。
- 测试脚本支持 `--offline-alert`，可发送命中邮箱下线检测端默认关键词的测试邮件。

# v1.6.12

- 邮箱下线检测端新增 `message_template`，支持为主动提醒配置自定义消息模板。
- 邮箱下线检测端新增 `at_targets`，支持主动提醒前 @ 指定 QQ 或 @ 全体成员。

# v1.6.11

- 新增 `offline_mail_monitors` 邮箱下线检测端配置，支持多条 IMAP 检测规则。
- 邮箱检测端可指定发送机器人、目标会话、检测邮箱、检测间隔和下线邮件关键词。
- 新增邮箱检测端 UID 状态持久化，首次启动只记录当前最新邮件，后续仅推送新下线邮件。
- 新增邮箱检测端测试，覆盖配置解析、IMAP 拉取过滤、状态保存和主动发送。

# v1.6.10

- 调整账号下线告警邮件内容：主题和正文改为纯英文，避免部分邮件客户端显示中文乱码。

# v1.6.9

- 调整音乐搜索默认配置：`music_search.api_base_url` 不再内置任何私有服务器地址，部署时需自行填写可用的网易云音乐 API 地址。

# v1.6.8

- 新增 AIOCQHTTP `bot_offline` 账号下线通知检测。
- 新增 `offline_email_alert` 配置项，支持通过 QQ 邮箱 SMTP 发送下线告警邮件。
- 新增账号下线邮件通知测试，覆盖 notice 检测、配置解析、SMTP 调用和插件 handler。

# v1.6.7

- 新增网易云音乐 API 服务手动重启文档，记录 `ncm-api` 容器状态检查、重启、健康检查和日志注意事项。
- README 增加服务器运维文档入口。

# v1.6.6

- 调整网易云扫码登录持久化目录：Cookie 和临时二维码改为保存到 AstrBot 官方插件数据目录 `data/plugin_data/astrbot_plugin_util/netease_login/`。
- 移除源码插件目录下的运行期登录数据忽略规则，避免混用插件代码目录和 AstrBot 持久化目录。

# v1.6.5

- 调整网易云扫码登录 Cookie 保存方式：改为写入插件数据目录下的持久化文件，插件重启后自动加载，不再只依赖运行时配置对象。
- 调整 `/网易云登录` 二维码发送方式：二维码作为独立图片消息直接发送，提示文字单独发送。
- 新增运行期登录目录忽略规则，避免 Cookie 和临时二维码图片被提交。

# v1.6.4

- 新增 `/网易云登录`、`/音乐登录`、`/点歌登录` 指令：发送网易云音乐扫码登录二维码，扫码确认后自动保存 Cookie 到 `music_search.cookie`。
- 新增网易云二维码登录状态轮询，支持登录成功、二维码过期、超时和接口异常提示。
- 新增扫码登录回归测试，覆盖 Cookie 持久化和二维码过期路径。

# v1.6.3

- 修复点歌成功路径在常规回复 `yield` 后不会继续执行的问题：选歌成功后歌曲信息、封面和语音均改为在处理器内直接 `event.send`。
- 新增点歌信息发送日志，用于确认选歌成功路径是否已进入直接发送阶段。

# v1.6.2

- 调整点歌音频发送链路：歌曲信息和封面仍走常规回复结果，音频 `Record` 改为在指令处理器内直接 `event.send` 单独发送。
- 新增点歌音频发送日志和失败兜底，发送失败时会返回可点击播放链接，方便定位 AIOCQHTTP 语音兼容问题。

# v1.6.1

- 修复点歌选择后音频消息可能不发送的问题：歌曲信息、封面和 `Record` 音频现在会放在同一个消息链中返回，避免其他装饰插件在第一条结果后终止事件传播。

# v1.6.0

- 新增 `/点歌`、`/music`、`/听歌`、`/网易云` 音乐搜索与点歌功能，支持搜索候选、数字选择、歌曲信息、封面和语音播放消息。
- 新增 `music_search` 配置项，可配置功能开关、网易云音乐 API 地址、优先音质、搜索数量、选择超时时间和 Cookie。
- 新增音乐 API 地址配置，并兼容只填写 `host:port` 的配置写法。

# v1.5.6

- 新增 `group_history.enable_group_history_feature` 配置开关，可整体开启或关闭 `/群友史` 聊天记录构造功能。
- 关闭群友史功能后，`/群友史` 会提示功能已关闭，不再生成合并转发节点。

# v1.5.5

- 群友史昵称解析先对 QQ 号去重，再调用 `get_stranger_info`，避免同一 QQ 在多段聊天记录中重复查询。
- 群友史昵称获取失败时默认使用 `QQ用户` 作为合并转发节点昵称。
- 群友史指令装饰器直接使用 `@filter.command("群友史")`，不再通过 `GROUP_HISTORY_PREFIX` 常量注册。

# v1.5.4

- 群友史从全消息监听前缀检测改为 `@filter.command("群友史")` 指令触发。
- 纯文本兜底解析支持命令剥离后的参数文本，并保持图片段落解析逻辑在 `core/group_history.py`。

# v1.5.3

- 群友史节点昵称查询改为通过当前 bot 调用 `get_stranger_info`，移除第三方 QQ 昵称接口依赖。
- 新增昵称查询使用 bot API、无 bot 时返回空昵称的回归测试。

# v1.5.2

- 将构造聊天记录入口从 `伪造消息` 改名为 `群友史`，帮助指令改为 `/群友史帮助`。
- 将群友史聊天记录解析、QQ 昵称查询、图片归属和合并转发节点构造移动到 `core/group_history.py`，避免继续堆在 `main.py`。
- 更新回归测试覆盖新入口、旧入口忽略和 core 模块节点构造。

# v1.5.1

- 将上一版 `/群友史` 随机生成逻辑调整为参考 FixSessionFaker 的 `伪造消息` 构造聊天记录能力。
- 支持 `伪造消息 QQ号 内容 | QQ号 内容 | ...` 生成合并转发节点，并保留图片跟随所在消息段的行为。
- 新增 `/伪造帮助` 指令与伪造消息解析、转发节点构造的回归测试。

# v1.5.0

- 新增 `/群友史` 指令：每天按群号和日期稳定抽取一名群友，生成“群友史”并以合并转发节点展示。
- 读取 AIOCQHTTP 群成员列表作为抽取来源，过滤机器人自身；成员列表不可用时退回命令发送者。
- 新增群友史生成、候选过滤、合并转发输出的回归测试。

# v1.4.2

- 土味情话按词库原文发送，不再在句末自动追加“喵”。
- 新增土味情话原文输出的回归测试。

# v1.4.1

- 明确使用插件文件位置解析 `core/love_messages.txt` 的绝对路径。
- 新增切换进程工作目录后仍能读取内置词库的回归测试。

# v1.4.0

- 新增 `/土味情话 [QQ号|@用户]` 指令，不需要分群配置。
- 目标解析采用 NullDox 指令方案：显式 QQ、非机器人 `@`、机器人 `@`、发送者依次回退。
- 将预备情话迁移到插件内置 `core/love_messages.txt`，不打包 `docs/情话.md`。
- 随机情话自动追加“喵”语气。

# v1.3.3

- 新增随机群友土味情话功能设计文档。
- 明确首版命令触发、分群配置、成员过滤、冷却限制、异常处理和测试范围。

# v1.3.2

- 支持为同一个群号添加多条关键词语音规则，不再由后项覆盖前项。
- 同群规则按配置顺序匹配，一条消息只发送第一条有效匹配规则的语音。

# v1.3.1

- 将每群语音配置从单个文件 `audio_path` 改为单个目录 `audio_directory`。
- 目录内存在多个语音文件时，按文件名排序发送第一个支持格式的文件。
- 不递归扫描子目录，目录不存在或没有有效语音时跳过发送。

# v1.3.0

- 将分群关键词输出由文本台词改为本地语音文件。
- 配置项改为 `group_keyword_voices`，每群通过 `audio_path` 选择语音文件。
- 语音文件缺失时跳过发送并记录警告。
- 原 v1.2.0 的 `group_keyword_replies` 配置不再读取，升级后需要重新配置。

# v1.2.0

- 新增分群关键词台词配置，仅对明确配置的群聊生效。
- 支持每个群聊独立开启或关闭关键词检测。
- 支持为每个群配置多个触发关键词和多行输出台词。
- 新增关键词匹配、分群隔离、关闭开关和私聊跳过测试。

# v1.1.5

- 新增功能任务清单，区分待开发、外部依赖和暂缓事项。
- 为可开发功能补充实施步骤、测试要求与验收标准。
- 在 README 中增加开发计划入口。

# v1.1.4

- 移除语音生成命令。
- 移除骰子指令处理。
- 将 `CONSTRAINTS.md` 中的开发约束同步到 `AGENTS.md`。
